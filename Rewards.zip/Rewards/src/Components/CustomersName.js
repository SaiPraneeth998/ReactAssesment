import React from "react";

const CustomerName = ({ name }) => {
  return <h1>{name}</h1>;
};
export default CustomerName;
