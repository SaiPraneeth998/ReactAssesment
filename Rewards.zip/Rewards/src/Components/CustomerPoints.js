import React from "react";

const CustomerPoints = ({ month, points }) => {
  return (
    <p>
      {month}: {points} points
    </p>
  );
};
export default CustomerPoints;
